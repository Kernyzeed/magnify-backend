-- ============================================================
-- MAGNIFY SERVICES INC. – Full Database Schema
-- Created by Falcon Africa | PostgreSQL 15+
-- ============================================================

-- ── Extensions ──────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── ENUMS ───────────────────────────────────────────────────
CREATE TYPE user_role AS ENUM ('owner', 'admin', 'supervisor', 'staff', 'auditor');
CREATE TYPE staff_status AS ENUM ('active', 'inactive', 'suspended', 'terminated', 'pending');
CREATE TYPE shift_type AS ENUM ('day', 'evening', 'overnight', 'awake_overnight', 'on_call');
CREATE TYPE shift_status AS ENUM ('scheduled', 'confirmed', 'in_progress', 'completed', 'missed', 'cancelled', 'open');
CREATE TYPE cert_status AS ENUM ('valid', 'expiring_soon', 'expired', 'pending');
CREATE TYPE care_level AS ENUM ('low', 'moderate', 'high', 'intensive');
CREATE TYPE incident_severity AS ENUM ('minor', 'moderate', 'serious', 'critical');
CREATE TYPE incident_status AS ENUM ('open', 'under_review', 'reported_to_lara', 'closed');
CREATE TYPE alert_type AS ENUM ('cert_expiry', 'shift_uncovered', 'ratio_violation', 'incident', 'care_plan_due', 'background_check');
CREATE TYPE alert_priority AS ENUM ('low', 'medium', 'high', 'critical');

-- ── HOMES ───────────────────────────────────────────────────
CREATE TABLE homes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(120) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(80) NOT NULL,
    state CHAR(2) DEFAULT 'MI',
    zip VARCHAR(10),
    license_number VARCHAR(60) UNIQUE NOT NULL,
    license_expiry DATE NOT NULL,
    max_capacity INT NOT NULL CHECK (max_capacity BETWEEN 1 AND 6),
    current_occupancy INT DEFAULT 0,
    phone VARCHAR(20),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── USERS (Auth) ────────────────────────────────────────────
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role user_role NOT NULL DEFAULT 'staff',
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMPTZ,
    mfa_secret TEXT,
    mfa_enabled BOOLEAN DEFAULT FALSE,
    password_reset_token TEXT,
    password_reset_expires TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── STAFF PROFILES ──────────────────────────────────────────
CREATE TABLE staff (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    home_id UUID REFERENCES homes(id) ON DELETE SET NULL,
    employee_id VARCHAR(20) UNIQUE,
    first_name VARCHAR(80) NOT NULL,
    last_name VARCHAR(80) NOT NULL,
    date_of_birth DATE NOT NULL,
    phone VARCHAR(20),
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    address TEXT,
    hire_date DATE NOT NULL,
    employment_type VARCHAR(20) CHECK (employment_type IN ('full_time','part_time','on_call','contract')),
    job_title VARCHAR(100),
    status staff_status DEFAULT 'pending',
    -- Michigan AFC Compliance
    background_check_date DATE,
    background_check_expiry DATE,
    background_check_status VARCHAR(20),
    sex_offender_check_date DATE,
    central_registry_check_date DATE,
    is_age_compliant BOOLEAN DEFAULT FALSE, -- Must be 18+
    -- Qualifications
    education_level VARCHAR(60),
    notes TEXT,
    profile_photo_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── CERTIFICATIONS ──────────────────────────────────────────
CREATE TABLE certification_types (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(120) NOT NULL,
    description TEXT,
    is_required_michigan BOOLEAN DEFAULT FALSE,
    validity_months INT,  -- NULL = no expiry
    renewal_alert_days INT DEFAULT 30,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE staff_certifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    staff_id UUID NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
    cert_type_id UUID NOT NULL REFERENCES certification_types(id),
    issued_date DATE NOT NULL,
    expiry_date DATE,
    issuing_body VARCHAR(120),
    certificate_number VARCHAR(80),
    document_url TEXT,
    status cert_status DEFAULT 'valid',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(staff_id, cert_type_id, issued_date)
);

-- ── STAFF AVAILABILITY ──────────────────────────────────────
CREATE TABLE staff_availability (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    staff_id UUID NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
    day_of_week INT NOT NULL CHECK (day_of_week BETWEEN 0 AND 6), -- 0=Sun
    shift_type shift_type NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    notes TEXT,
    effective_from DATE DEFAULT CURRENT_DATE,
    effective_to DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── RESIDENTS ───────────────────────────────────────────────
CREATE TABLE residents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    home_id UUID NOT NULL REFERENCES homes(id),
    first_name VARCHAR(80) NOT NULL,
    last_name VARCHAR(80) NOT NULL,
    date_of_birth DATE NOT NULL,
    admission_date DATE NOT NULL,
    discharge_date DATE,
    care_level care_level NOT NULL,
    primary_diagnosis TEXT,
    secondary_diagnoses TEXT[],
    physician_name VARCHAR(120),
    physician_phone VARCHAR(20),
    guardian_name VARCHAR(120),
    guardian_phone VARCHAR(20),
    guardian_email VARCHAR(255),
    guardian_relationship VARCHAR(60),
    medicaid_number VARCHAR(40),
    medicare_number VARCHAR(40),
    insurance_provider VARCHAR(100),
    insurance_policy_number VARCHAR(60),
    room_number VARCHAR(10),
    is_active BOOLEAN DEFAULT TRUE,
    photo_url TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── RESIDENT CARE PLANS ─────────────────────────────────────
CREATE TABLE care_plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    resident_id UUID NOT NULL REFERENCES residents(id) ON DELETE CASCADE,
    plan_date DATE NOT NULL,
    review_date DATE NOT NULL,
    next_review_date DATE NOT NULL,
    goals TEXT[],
    adl_assistance_level VARCHAR(20), -- independent, assist, total
    mobility_level VARCHAR(60),
    communication_level VARCHAR(60),
    behavioral_notes TEXT,
    dietary_restrictions TEXT,
    fall_risk BOOLEAN DEFAULT FALSE,
    elopement_risk BOOLEAN DEFAULT FALSE,
    supervision_level VARCHAR(60),
    created_by UUID REFERENCES staff(id),
    approved_by UUID REFERENCES staff(id),
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── MEDICATIONS ─────────────────────────────────────────────
CREATE TABLE medications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    resident_id UUID NOT NULL REFERENCES residents(id) ON DELETE CASCADE,
    medication_name VARCHAR(120) NOT NULL,
    dosage VARCHAR(60),
    frequency VARCHAR(80),
    route VARCHAR(40),
    prescriber VARCHAR(120),
    start_date DATE,
    end_date DATE,
    special_instructions TEXT,
    requires_certified_staff BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── SCHEDULES ───────────────────────────────────────────────
CREATE TABLE schedules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    home_id UUID NOT NULL REFERENCES homes(id),
    week_start DATE NOT NULL,
    week_end DATE NOT NULL,
    is_published BOOLEAN DEFAULT FALSE,
    is_locked BOOLEAN DEFAULT FALSE,
    generated_by UUID REFERENCES users(id),
    published_at TIMESTAMPTZ,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(home_id, week_start)
);

-- ── SHIFTS ──────────────────────────────────────────────────
CREATE TABLE shifts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    schedule_id UUID NOT NULL REFERENCES schedules(id) ON DELETE CASCADE,
    home_id UUID NOT NULL REFERENCES homes(id),
    staff_id UUID REFERENCES staff(id) ON DELETE SET NULL,
    shift_date DATE NOT NULL,
    shift_type shift_type NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status shift_status DEFAULT 'scheduled',
    is_supervisor_shift BOOLEAN DEFAULT FALSE,
    required_certs TEXT[], -- certification IDs required for this shift
    notes TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── SHIFT SWAPS ─────────────────────────────────────────────
CREATE TABLE shift_swap_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    requesting_staff_id UUID NOT NULL REFERENCES staff(id),
    covering_staff_id UUID REFERENCES staff(id),
    shift_id UUID NOT NULL REFERENCES shifts(id),
    reason TEXT,
    status VARCHAR(20) DEFAULT 'pending', -- pending, approved, denied
    reviewed_by UUID REFERENCES users(id),
    reviewed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── TIME & ATTENDANCE ───────────────────────────────────────
CREATE TABLE time_entries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    staff_id UUID NOT NULL REFERENCES staff(id),
    shift_id UUID REFERENCES shifts(id),
    home_id UUID NOT NULL REFERENCES homes(id),
    clock_in TIMESTAMPTZ NOT NULL,
    clock_out TIMESTAMPTZ,
    clock_in_lat DECIMAL(9,6),
    clock_in_lng DECIMAL(9,6),
    clock_out_lat DECIMAL(9,6),
    clock_out_lng DECIMAL(9,6),
    clock_in_photo_url TEXT,
    clock_out_photo_url TEXT,
    hours_worked DECIMAL(5,2),
    overtime_hours DECIMAL(5,2) DEFAULT 0,
    is_approved BOOLEAN DEFAULT FALSE,
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMPTZ,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── RESIDENT DAILY ACTIVITIES ───────────────────────────────
CREATE TABLE resident_activities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    resident_id UUID NOT NULL REFERENCES residents(id),
    shift_id UUID REFERENCES shifts(id),
    staff_id UUID REFERENCES staff(id),
    activity_date DATE NOT NULL,
    activity_type VARCHAR(80),
    description TEXT,
    completed BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── MEDICATION ADMINISTRATION RECORDS ───────────────────────
CREATE TABLE medication_admin_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    medication_id UUID NOT NULL REFERENCES medications(id),
    resident_id UUID NOT NULL REFERENCES residents(id),
    administered_by UUID NOT NULL REFERENCES staff(id),
    scheduled_time TIMESTAMPTZ,
    administered_time TIMESTAMPTZ NOT NULL,
    dosage_given VARCHAR(60),
    route VARCHAR(40),
    was_refused BOOLEAN DEFAULT FALSE,
    refusal_reason TEXT,
    side_effects_noted TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── INCIDENTS ───────────────────────────────────────────────
CREATE TABLE incidents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    home_id UUID NOT NULL REFERENCES homes(id),
    resident_id UUID REFERENCES residents(id),
    reported_by UUID NOT NULL REFERENCES staff(id),
    incident_date TIMESTAMPTZ NOT NULL,
    incident_type VARCHAR(80),
    severity incident_severity NOT NULL,
    status incident_status DEFAULT 'open',
    description TEXT NOT NULL,
    immediate_action TEXT,
    witnesses TEXT[],
    lara_report_required BOOLEAN DEFAULT FALSE,
    lara_report_number VARCHAR(60),
    lara_report_date DATE,
    follow_up_notes TEXT,
    closed_by UUID REFERENCES users(id),
    closed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── ALERTS & NOTIFICATIONS ──────────────────────────────────
CREATE TABLE alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    home_id UUID REFERENCES homes(id),
    alert_type alert_type NOT NULL,
    priority alert_priority NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    related_staff_id UUID REFERENCES staff(id),
    related_resident_id UUID REFERENCES residents(id),
    related_shift_id UUID REFERENCES shifts(id),
    is_read BOOLEAN DEFAULT FALSE,
    is_resolved BOOLEAN DEFAULT FALSE,
    resolved_by UUID REFERENCES users(id),
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── AUDIT LOG ───────────────────────────────────────────────
CREATE TABLE audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(80),
    record_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── PAYROLL EXPORT ──────────────────────────────────────────
CREATE TABLE payroll_exports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    home_id UUID REFERENCES homes(id),
    exported_by UUID REFERENCES users(id),
    exported_at TIMESTAMPTZ DEFAULT NOW(),
    record_count INT,
    total_hours DECIMAL(8,2),
    file_url TEXT,
    format VARCHAR(20) DEFAULT 'xlsx'
);

-- ── COMPLIANCE REPORTS ──────────────────────────────────────
CREATE TABLE compliance_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    home_id UUID NOT NULL REFERENCES homes(id),
    report_type VARCHAR(80),
    report_period_start DATE,
    report_period_end DATE,
    generated_by UUID REFERENCES users(id),
    generated_at TIMESTAMPTZ DEFAULT NOW(),
    file_url TEXT,
    submitted_to_lara BOOLEAN DEFAULT FALSE,
    lara_submission_date DATE
);

-- ── INDEXES ─────────────────────────────────────────────────
CREATE INDEX idx_shifts_date ON shifts(shift_date);
CREATE INDEX idx_shifts_home ON shifts(home_id);
CREATE INDEX idx_shifts_staff ON shifts(staff_id);
CREATE INDEX idx_time_entries_staff ON time_entries(staff_id);
CREATE INDEX idx_time_entries_clock_in ON time_entries(clock_in);
CREATE INDEX idx_staff_certs_expiry ON staff_certifications(expiry_date);
CREATE INDEX idx_alerts_unread ON alerts(is_read, is_resolved);
CREATE INDEX idx_audit_log_user ON audit_log(user_id, created_at);
CREATE INDEX idx_incidents_home ON incidents(home_id, status);
CREATE INDEX idx_residents_home ON residents(home_id, is_active);

-- ── SEED: Michigan Required Certifications ───────────────────
INSERT INTO certification_types (name, description, is_required_michigan, validity_months, renewal_alert_days) VALUES
('Pre-Service Training (AFC)', 'Michigan required pre-service training for AFC staff', TRUE, NULL, 60),
('First Aid', 'Standard First Aid certification', TRUE, 24, 60),
('CPR/AED', 'Cardiopulmonary Resuscitation certification', TRUE, 24, 60),
('Medication Administration', 'Certified medication administration for AFC', TRUE, 12, 45),
('Resident Rights Training', 'Michigan AFC resident rights training', TRUE, 12, 30),
('Fire Safety Training', 'Fire safety and evacuation training', TRUE, 12, 30),
('Bloodborne Pathogen Training', 'OSHA bloodborne pathogen standard', TRUE, 12, 30),
('Dementia Care Training', 'Specialized dementia care', FALSE, 24, 60),
('Mental Health First Aid', 'Mental health awareness and response', FALSE, 36, 60),
('Background Check Clearance', 'ICHAT Michigan background check', TRUE, NULL, 30),
('Central Registry Clearance', 'Michigan central registry check', TRUE, NULL, 30);

-- ── VIEWS ───────────────────────────────────────────────────
CREATE VIEW v_current_staffing AS
SELECT
    h.name AS home_name,
    s.id AS shift_id,
    s.shift_date,
    s.shift_type,
    s.start_time,
    s.end_time,
    s.status,
    st.first_name || ' ' || st.last_name AS staff_name,
    s.is_supervisor_shift
FROM shifts s
JOIN homes h ON h.id = s.home_id
LEFT JOIN staff st ON st.id = s.staff_id
WHERE s.shift_date = CURRENT_DATE;

CREATE VIEW v_expiring_certs AS
SELECT
    st.first_name || ' ' || st.last_name AS staff_name,
    ct.name AS cert_name,
    sc.expiry_date,
    (sc.expiry_date - CURRENT_DATE) AS days_until_expiry,
    sc.status
FROM staff_certifications sc
JOIN staff st ON st.id = sc.staff_id
JOIN certification_types ct ON ct.id = sc.cert_type_id
WHERE sc.expiry_date IS NOT NULL
  AND sc.expiry_date <= CURRENT_DATE + INTERVAL '60 days'
ORDER BY sc.expiry_date ASC;

CREATE VIEW v_staffing_ratio AS
SELECT
    h.id AS home_id,
    h.name AS home_name,
    h.current_occupancy AS resident_count,
    COUNT(s.id) FILTER (WHERE s.shift_date = CURRENT_DATE AND s.status IN ('scheduled','in_progress')) AS shifts_today,
    h.current_occupancy::FLOAT / NULLIF(COUNT(s.id) FILTER (WHERE s.shift_date = CURRENT_DATE AND s.status IN ('scheduled','in_progress')), 0) AS resident_to_staff_ratio
FROM homes h
LEFT JOIN shifts s ON s.home_id = h.id
GROUP BY h.id, h.name, h.current_occupancy;
