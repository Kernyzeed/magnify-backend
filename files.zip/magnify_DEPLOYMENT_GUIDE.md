# MAGNIFY SERVICES INC. – Deployment & Architecture Guide
# Created by Falcon Africa

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    MAGNIFY SERVICES PLATFORM                 │
├─────────────────────────────────────────────────────────────┤
│  CLIENTS                                                     │
│  ┌──────────────────┐  ┌──────────────────┐                 │
│  │  Web Dashboard   │  │  Mobile App      │                 │
│  │  (Next.js)       │  │  (React Native)  │                 │
│  │  Admin/Owner     │  │  Staff Clock-In  │                 │
│  └────────┬─────────┘  └────────┬─────────┘                 │
│           │                     │                           │
│  ┌────────▼─────────────────────▼────────┐                  │
│  │         API Gateway (Express.js)       │                  │
│  │      JWT Auth + Rate Limiting          │                  │
│  │         Port 3001 / HTTPS             │                  │
│  └────────┬──────────────────────────────┘                  │
│           │                                                  │
│  ┌────────▼──────────────┐  ┌─────────────────────┐         │
│  │  Supabase (PostgreSQL) │  │  File Storage       │         │
│  │  - Staff records       │  │  - Cert documents   │         │
│  │  - Resident data       │  │  - Clock-in photos  │         │
│  │  - Schedules/Shifts    │  │  - Reports (PDF)    │         │
│  │  - Audit logs          │  └─────────────────────┘         │
│  └────────┬──────────────┘                                   │
│           │                                                  │
│  ┌────────▼──────────────┐  ┌─────────────────────┐         │
│  │  Cron Jobs (Node)     │  │  Notifications      │         │
│  │  - Cert expiry check  │  │  - Twilio SMS        │         │
│  │  - Open shift alerts  │  │  - SendGrid Email    │         │
│  │  - Ratio monitoring   │  │  - Push (Firebase)   │         │
│  └───────────────────────┘  └─────────────────────┘         │
└─────────────────────────────────────────────────────────────┘
```

## Deployment Steps

### 1. Database (Supabase – Free/Pro)
```bash
# Go to supabase.com → New Project
# Name: magnify-services
# Region: US East (closest to Michigan)
# Copy the URL and anon/service keys

# Run schema in Supabase SQL Editor:
# (paste contents of schema/schema.sql)
```

### 2. Backend (Railway or Render – Recommended)
```bash
# Option A: Railway (recommended)
npm install -g @railway/cli
railway login
railway init
railway up

# Option B: Render
# Push to GitHub → connect Render → auto-deploy

# Set environment variables:
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=your-service-role-key
JWT_SECRET=your-256-bit-random-secret
ALLOWED_ORIGINS=https://magnify.yourdomain.com
TWILIO_ACCOUNT_SID=your-twilio-sid
TWILIO_AUTH_TOKEN=your-twilio-token
TWILIO_PHONE=+1xxxxxxxxxx
SENDGRID_API_KEY=your-sendgrid-key
FIREBASE_SERVER_KEY=your-firebase-key
PORT=3001
```

### 3. Frontend (Vercel – Recommended)
```bash
npx create-next-app@latest magnify-frontend --typescript
# Copy frontend components
vercel deploy

# Environment variables in Vercel dashboard:
NEXT_PUBLIC_API_URL=https://your-backend.railway.app/api
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

### 4. Mobile App (Expo)
```bash
npm install -g expo-cli
expo init MagnifyMobile --template expo-template-blank-typescript
expo publish  # for OTA updates
# Build with EAS Build for App Store / Play Store
eas build --platform all
```

### 5. Custom Domain Setup
```
# Add DNS records:
# magnify.yourdomain.com   → Vercel (frontend)
# api.yourdomain.com       → Railway (backend)
# Or use subdomain of existing site via CNAME
```

## Security Checklist
- [x] JWT tokens with 12h expiry
- [x] bcrypt password hashing (rounds: 12)
- [x] Rate limiting on all API endpoints
- [x] Helmet.js security headers
- [x] CORS restricted to allowed origins
- [x] Role-based access control (RBAC)
- [x] Full audit trail on all data changes
- [x] HTTPS enforced (via Vercel/Railway)
- [x] Supabase Row Level Security (RLS) policies
- [x] File uploads: type + size validation
- [x] GPS + photo verification for clock-in

## Monthly Cost Estimate
| Service        | Plan        | Cost/month |
|----------------|-------------|------------|
| Supabase       | Pro         | $25        |
| Railway        | Starter     | $10–20     |
| Vercel         | Pro         | $20        |
| Twilio SMS     | Pay-as-go   | ~$10       |
| SendGrid       | Essentials  | $15        |
| Expo EAS       | Production  | $29        |
| **TOTAL**      |             | **~$109**  |

## Michigan AFC Compliance Built-In
- R 400.633: Staffing ratios enforced per shift
- Background check expiry tracking (ICHAT)
- Central registry clearance alerts
- 18+ age verification on staff onboarding
- Pre-service training completion required before first shift
- Medication administration cert linked to med tasks
- Full electronic records suitable for LARA inspection
- One-click compliance report generation
