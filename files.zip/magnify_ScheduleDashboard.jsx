// ============================================================
// MAGNIFY SERVICES – Scheduling Dashboard (React/Next.js)
// Created by Falcon Africa
// ============================================================

import { useState, useEffect, useCallback } from 'react'
import { format, startOfWeek, addDays, parseISO } from 'date-fns'
import { DndContext, DragOverlay, useDraggable, useDroppable } from '@dnd-kit/core'
import toast from 'react-hot-toast'
import { api } from '@/lib/api'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { LoadingSpinner } from '@/components/ui/LoadingSpinner'
import { RatioWarning } from '@/components/schedule/RatioWarning'

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const SHIFTS = [
  { key: 'day',       label: 'Day',   time: '7a–3p',  color: 'blue'   },
  { key: 'evening',   label: 'Eve',   time: '3p–11p', color: 'purple' },
  { key: 'overnight', label: 'NOC',   time: '11p–7a', color: 'slate'  },
]

// ── Draggable Staff Card ─────────────────────────────────────
function StaffCard({ staff, compact = false }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: `staff-${staff.id}`, data: { staff }
  })
  return (
    <div
      ref={setNodeRef} {...listeners} {...attributes}
      className={`staff-card ${isDragging ? 'dragging' : ''} ${compact ? 'compact' : ''}`}
    >
      <div className="staff-avatar">{staff.first_name[0]}{staff.last_name[0]}</div>
      {!compact && (
        <div className="staff-info">
          <span className="staff-name">{staff.first_name} {staff.last_name}</span>
          <span className="staff-role">{staff.job_title}</span>
        </div>
      )}
    </div>
  )
}

// ── Droppable Shift Cell ─────────────────────────────────────
function ShiftCell({ shift, date, shiftType, onAssign, onRemove }) {
  const { setNodeRef, isOver } = useDroppable({
    id: `cell-${date}-${shiftType}`, data: { date, shiftType, shiftId: shift?.id }
  })
  const isOpen = !shift?.staff_id

  return (
    <div ref={setNodeRef} className={`shift-cell ${isOver ? 'drop-over' : ''} ${isOpen ? 'open' : 'filled'}`}>
      {shift ? (
        shift.staff_id ? (
          <div className="shift-assigned" style={{ background: SHIFTS.find(s=>s.key===shiftType)?.color === 'blue' ? '#DBEAFE' : shiftType==='evening' ? '#F3E8FF' : '#1e293b' }}>
            <span className="shift-staff-name">
              {shift.staff?.first_name} {shift.staff?.last_name?.[0]}.
            </span>
            <button className="remove-btn" onClick={() => onRemove(shift.id)}>×</button>
          </div>
        ) : (
          <div className="shift-open">
            <span>Open</span>
            <button className="btn-assign" onClick={() => onAssign(shift.id, date, shiftType)}>Fill</button>
          </div>
        )
      ) : (
        <div className="shift-empty">Drop staff here</div>
      )}
    </div>
  )
}

// ── Main Schedule Component ──────────────────────────────────
export default function ScheduleDashboard({ homeId }) {
  const [weekStart, setWeekStart] = useState(startOfWeek(new Date()))
  const [schedule, setSchedule] = useState(null)
  const [staff, setStaff] = useState([])
  const [loading, setLoading] = useState(true)
  const [generating, setGenerating] = useState(false)
  const [activeStaff, setActiveStaff] = useState(null)
  const [warnings, setWarnings] = useState([])

  const weekDays = DAYS.map((_, i) => addDays(weekStart, i))

  const loadSchedule = useCallback(async () => {
    setLoading(true)
    try {
      const [schedData, staffData] = await Promise.all([
        api.get(`/schedules?home_id=${homeId}&week_start=${format(weekStart, 'yyyy-MM-dd')}`),
        api.get(`/staff?home_id=${homeId}&status=active`)
      ])
      setSchedule(schedData)
      setStaff(staffData)
    } catch (e) { toast.error('Failed to load schedule') }
    finally { setLoading(false) }
  }, [homeId, weekStart])

  useEffect(() => { loadSchedule() }, [loadSchedule])

  const generateSchedule = async () => {
    setGenerating(true)
    try {
      const result = await api.post('/schedules/generate', {
        home_id: homeId, week_start: format(weekStart, 'yyyy-MM-dd')
      })
      setWarnings(result.warnings || [])
      await loadSchedule()
      toast.success(`Schedule generated! ${result.stats.open} open shifts need coverage.`)
    } catch (e) { toast.error('Generation failed') }
    finally { setGenerating(false) }
  }

  const handleDragEnd = async ({ active, over }) => {
    setActiveStaff(null)
    if (!over) return
    const staffId = active.data.current.staff.id
    const { shiftId } = over.data.current
    if (!shiftId) return
    try {
      await api.put(`/shifts/${shiftId}/assign`, { staff_id: staffId })
      await loadSchedule()
      toast.success('Shift assigned!')
    } catch (e) { toast.error('Assignment failed') }
  }

  const getShiftForCell = (date, shiftType) => {
    if (!schedule?.shifts) return null
    return schedule.shifts.find(s =>
      s.shift_date === format(date, 'yyyy-MM-dd') && s.shift_type === shiftType
    )
  }

  const openShiftCount = schedule?.shifts?.filter(s => !s.staff_id)?.length || 0

  if (loading) return <LoadingSpinner message="Loading schedule..." />

  return (
    <DndContext onDragStart={({ active }) => setActiveStaff(active.data.current.staff)} onDragEnd={handleDragEnd}>
      <div className="schedule-page">

        {/* Header */}
        <div className="schedule-header">
          <div className="week-nav">
            <button onClick={() => setWeekStart(d => addDays(d, -7))} className="nav-btn">← Prev</button>
            <h2 className="week-label">
              Week of {format(weekStart, 'MMM d')} – {format(addDays(weekStart, 6), 'MMM d, yyyy')}
            </h2>
            <button onClick={() => setWeekStart(d => addDays(d, 7))} className="nav-btn">Next →</button>
          </div>
          <div className="schedule-actions">
            {openShiftCount > 0 && (
              <span className="open-badge">{openShiftCount} open shifts</span>
            )}
            <Button onClick={generateSchedule} loading={generating} variant="gold">
              ✦ Auto-Generate
            </Button>
            <Button onClick={() => window.print()} variant="ghost">Export PDF</Button>
          </div>
        </div>

        {/* Ratio Warnings */}
        {warnings.length > 0 && <RatioWarning warnings={warnings} />}

        <div className="schedule-layout">
          {/* Staff Panel */}
          <div className="staff-panel">
            <h3 className="panel-title">Available Staff</h3>
            <p className="panel-hint">Drag staff to assign shifts</p>
            <div className="staff-list">
              {staff.map(s => <StaffCard key={s.id} staff={s} />)}
            </div>
          </div>

          {/* Grid */}
          <div className="grid-wrap">
            <table className="sched-grid">
              <thead>
                <tr>
                  <th className="shift-label-col">Shift</th>
                  {weekDays.map((d, i) => (
                    <th key={i} className={format(d, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd') ? 'today' : ''}>
                      <div className="day-name">{DAYS[i]}</div>
                      <div className="day-date">{format(d, 'M/d')}</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {SHIFTS.map(shift => (
                  <tr key={shift.key}>
                    <td className="shift-label">
                      <Badge color={shift.color}>{shift.label}</Badge>
                      <span className="shift-time">{shift.time}</span>
                    </td>
                    {weekDays.map((day, di) => (
                      <td key={di}>
                        <ShiftCell
                          shift={getShiftForCell(day, shift.key)}
                          date={format(day, 'yyyy-MM-dd')}
                          shiftType={shift.key}
                          onAssign={(id) => {/* open assign modal */}}
                          onRemove={async (id) => {
                            await api.put(`/shifts/${id}/assign`, { staff_id: null })
                            await loadSchedule()
                          }}
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <DragOverlay>
        {activeStaff && <StaffCard staff={activeStaff} compact />}
      </DragOverlay>
    </DndContext>
  )
}
